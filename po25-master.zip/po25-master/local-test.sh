#!/bin/zsh
# Local wrapper to run the professor's test harness against THIS workspace project.
# It prepares a fake group 000 under po25-master/checked-out and copies your
# bci-core and bci-app folders there, applies the sane Makefiles, and runs tests.
#
# Usage:
#   ./local-test.sh             # uses DELIVERY=ei by default
#   DELIVERY=ef ./local-test.sh # choose delivery
#   JAVADIR=/path/to/uilib ./local-test.sh # where po-uilib.jar lives
set -e
set -u
set -o pipefail 2>/dev/null || true

# Ensure a sane PATH in case the environment is minimal
export PATH="/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:${PATH:-}"

SCRIPT_DIR=${0:a:h}
ROOT_DIR=${SCRIPT_DIR:h}
DELIVERY=${DELIVERY:-ei}
GROUP=000

# Resolve po-uilib.jar directory
if [ -z "${JAVADIR:-}" ]; then
  # Try common locations
  if [ -f "/usr/share/java/po-uilib.jar" ]; then
    export JAVADIR="/usr/share/java"
  elif [ -f "${ROOT_DIR}/../po-uilib.jar" ]; then
    export JAVADIR="${ROOT_DIR}/.."
  elif [ -f "${ROOT_DIR}/po-uilib.jar" ]; then
    export JAVADIR="${ROOT_DIR}"
  else
    echo "[ERROR] Could not locate po-uilib.jar."
    echo "- Put po-uilib.jar in one of: /usr/share/java, ${ROOT_DIR}, or ${ROOT_DIR}/.."
    echo "- Or run: JAVADIR=/path/containing/po-uilib.jar $0"
    exit 1
  fi
fi

# Prepare project directories
/bin/rm -rf "${SCRIPT_DIR}/checked-out" "${SCRIPT_DIR}/checked-out-ref"
/bin/mkdir -p "${SCRIPT_DIR}/checked-out/${GROUP}" "${SCRIPT_DIR}/checked-out-ref/${GROUP}"

echo "[INFO] Preparing project copy for group ${GROUP}..."
if command -v /usr/bin/rsync >/dev/null 2>&1; then
  /usr/bin/rsync -a --delete --exclude ".git" --exclude "po25-master" "${ROOT_DIR}/" "${SCRIPT_DIR}/checked-out/${GROUP}/"
  /usr/bin/rsync -a --delete --exclude ".git" --exclude "po25-master" "${ROOT_DIR}/" "${SCRIPT_DIR}/checked-out-ref/${GROUP}/"
else
  # Fallback: copy only the relevant project folders
  for d in bci-core bci-app; do
    if [ ! -d "${ROOT_DIR}/${d}" ]; then
      echo "[ERROR] Missing directory: ${ROOT_DIR}/${d}"
      exit 1
    fi
    /bin/cp -R "${ROOT_DIR}/${d}" "${SCRIPT_DIR}/checked-out/${GROUP}/"
    /bin/cp -R "${ROOT_DIR}/${d}" "${SCRIPT_DIR}/checked-out-ref/${GROUP}/"
  done
fi

# Overlay sane Makefiles to match harness expectations
/bin/cp -av "${SCRIPT_DIR}/sane/." "${SCRIPT_DIR}/checked-out/${GROUP}/" >/dev/null
/bin/cp -av "${SCRIPT_DIR}/sane/." "${SCRIPT_DIR}/checked-out-ref/${GROUP}/" >/dev/null

# Hint for test-group to skip strict ref diff in local runs
export LOCAL_TEST=1

# Run a single group using the harness
cd "${SCRIPT_DIR}"
./test-group.sh "$DELIVERY" "$GROUP"

LOGS_DIR="${SCRIPT_DIR}/logs/${DELIVERY}"
RESULTS_FILE="${LOGS_DIR}/${GROUP}.res.html"
if [ -f "$RESULTS_FILE" ]; then
  echo "\nSummary (raw):"
  /usr/bin/tail -n 2 "$RESULTS_FILE" || true
  echo "\nDetailed log: ${LOGS_DIR}/${GROUP}.log.html"
fi
