# Operações simples

* A-01-01-M-ok - Abrir aplicação ver menu inicial
* A-01-02-M-ok - Abrir aplicação ver restantes menus
* A-01-03-M-ok - Abrir aplicação com Livros em import e ver as obras   
* A-01-05-M-ok - Abrir aplicação com um user em import e ver os users

# Mostrar Obras

* A-02-01-M-ok - Ver obras sem nenhuma obra 
* A-02-02-M-ok - Ver obras com vários Livros  
* A-02-03-M-ok - Ver obras com vários DVDs  

# Mostrar Obra

* A-04-03-M-ok - Mostar livro existente com várias obras  
* A-04-04-M-ok - Mostar DVD existente com várias obras  

# Mostrar Utentes

* A-05-01-M-ok - Ver utentes sem nenhum utente
* A-05-02-M-ok - Abrir aplicação com utentes em import e ver os utentes

# Mostrar Data/Avançar

* A-06-01-M-ok - Mostrar data inicial 
* A-06-02-M-ok - Avançar data válida e Mostrar data

# Serialização/Desserialização (Abrir/Guardar em Ficheiro)

* A-07-01-M-ok - Serializar obras e guarda em works
* A-07-02-M-ok - Desserializar Obras e vê works
* A-07-07-M-ok - Abre ficheiro não existente

# Registrar Utente

* A-08-01-M-ok - Registrar utente sem estado inicial 
* A-08-02-M-ok - Registrar utente com estado inicial via import 

# Ver Obras de Criador

A-15-01-M-ok - Ver obras de criador só com um livros e só com um DVDs
A-15-02-M-ok - Ver obras de criadores de obra com vários criadores
A-15-03-M-ok - Ver obras de criador com livros e DVD's já ordenados
A-15-06-M-ok - Ver obras de criador não existente
