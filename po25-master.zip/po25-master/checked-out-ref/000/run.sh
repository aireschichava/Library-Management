#!/bin/sh
java -cp bci-app/bci-app.jar:bci-core/bci-core.jar:../po-uilib.jar bci.app.App
